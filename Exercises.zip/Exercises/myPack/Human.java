package myPack;
public class Human{

//String opener = "Open the door"; //package-private access.
public String closer = "Close the door";  //public access
//protected String left = "Fix the left door";  //protected access
//private String right = "Fix the right door";  //private access

}
/*
//System.out,println("Hello");


























	//int x = 2; instance variables, requires you to create the copy of the class e.g Human Sharon = new Human();
	//int x = 2;
	//int a, b, c = 10;
	//static int y = 2;  static variable

	
	//Human Sharon = new Human();	
	//System.out.println(Sharon.a);
        //System.out.println(Sharon.c);
        //System.out.println(Sharon.b);
	

//float d = 3.4f, e = 1.2f;
//int s = d/e; Results in compile error.
//int s = (int) (d/e);

//int i = 5, j = 10;
//float h = i/j; it results h=0;
//float h = (float) i/j; //it results h =0.5f;

//System.out.println(s);

	
	//Object x = new Object(); 
 	//System.out.println("Hello Room 6");
	//System.out.println(Human.x);
 	//System.out.println(x.toString());
 	//System.out.println(x.getClass());
 	//main(5);
 	//main("Sharon");

        //byte eyes = 2;   //local variables needs to have a value unlike instance variable
 	//short legs = 2;
	//short fnc = eyes * legs;   Compilation error
	//int fnc = eyes * legs;
	//int computerTraining = 3;
	//float temp = 1.3;  JVM sees this as a double
	//float temp = 1.3f;
	//double measure = 2.3;
	//long fingers = 10000;
	//System.out.println(fnc);
	//System.out.println("This is number " +computerTraining);
	//System.out.println(temp);
	//System.out.println(measure);
	//System.out.println(fingers);
  }


  //public static void main(String s){
  //System.out.println(s);
 //}
 //public static void main(int v){
 //System.out.println(v);
 //}

*/










